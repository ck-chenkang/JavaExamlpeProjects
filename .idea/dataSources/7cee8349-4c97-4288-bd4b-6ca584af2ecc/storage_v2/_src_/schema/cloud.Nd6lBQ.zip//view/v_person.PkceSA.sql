create view v_person as
select `cloud`.`person`.`Id` AS `id`
from `cloud`.`person`;

